<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication & Password
    |--------------------------------------------------------------------------
    |
    |
    */

    'reset' => 'Your password has been reset!',
    'sent' => 'We have emailed your password reset link!',
    'throttled' => 'Please wait before retrying.',
    'token' => 'This password reset link is invalid.',
    'user' => "No user found with this email address.",

];
